# EJERCICIO 2: MEDIDOR DE TENSI�N ARTERIAL

.data
    # registros del dispositivo mapeados en memoria
    TensionControl: .word 0 # escribir 1 inicia la medici�n
    TensionEstado:  .word 0, 0, 0, 0, 1 # 0: midiendo, 1: resultados listos (ARREGLO SIMULANDO EL INFLADO)
    TensionSistol:  .word 0 # resultado de tensi�n sist�lica (maxima presion)
    TensionDiastol: .word 0 # resultado de tensi�n diast�lica (minima presion)

    # mensajes para la consola
    msg_tension:    .asciiz "\n[Medicion finalizada]\nPresion Sistolica: "
    msg_diastol:    .asciiz "\nPresion Diastolica: "

.text
.globl main


# PROGRAMA PRINCIPAL
main:
    # INICIO SIMULACI�N DE PRECARGA
    # para que la espera activa no se quede en bucle infinito en el
    # simulador, precargamos los datos y marcamos el estado como listo (1)
    li $t0, 120             # valor simulado para sist�lica
    sw $t0, TensionSistol   # lo guardamos en memoria
    li $t0, 80              # valor simulado para diast�lica
    sw $t0, TensionDiastol  # lo guardamos en memoria
    # FIN SIMULACI�N DE PRECARGA

    # 1. llamar al controlador para iniciar y leer la tensi�n
    jal controlador_tension
    
    # 2. respaldar los resultados devueltos por la subrutina
    move $s0, $v0           # guardamos la presi�n sist�lica ($v0) en $s0
    move $s1, $v1           # guardamos la presi�n diast�lica ($v1) en $s1

    # 3. mostrar presi�n sist�lica (maxima presion)
    li $v0, 4               # c�digo 4 para imprimir texto
    la $a0, msg_tension     # direcci�n del mensaje sist�lico
    syscall
    
    li $v0, 1               # c�digo 1 para imprimir entero
    move $a0, $s0           # cargamos el valor sist�lico guardado
    syscall
    
    # 4. mostrar presi�n diast�lica (minima presion)
    li $v0, 4               # c�digo 4 para imprimir texto
    la $a0, msg_diastol     # direcci�n del mensaje diast�lico
    syscall
    
    li $v0, 1               # c�digo 1 para imprimir entero
    move $a0, $s1           # cargamos el valor diast�lico guardado
    syscall

    # 5. finalizar el programa
    li $v0, 10              # c�digo 10 para terminar la ejecuci�n limpiamente
    syscall                 # cierra el programa


# PROCEDIMIENTO: controlador_tension
controlador_tension:
    # 1. iniciar la medici�n
    la $t0, TensionControl  # cargamos la direcci�n de TensionControl
    li $t1, 1               # cargamos el comando de inicio (1 = activar brazalete)
    sw $t1, 0($t0)          # escribimos 1 en TensionControl

    # 2. bucle de espera (espera activa)
    la $t2, TensionEstado   # cargamos la direcci�n de TensionEstado
    
esperar_medicion_tension:
    lw $t3, 0($t2)          # leemos el estado actual del dispositivo
    addi $t2, $t2, 4        # SUMAMOS 4 BYTES: Avanza por el arreglo de 0s para simular el paso del tiempo
    beq $t3, $zero, esperar_medicion_tension # Si es 0 (midiendo), repite el bucle

    # 3. leer los datos cuando el estado es 1 (ya terminado)
    la $t4, TensionSistol   # cargamos direcci�n de Sist�lica
    lw $v0, 0($t4)          # guardamos el valor sist�lico en $v0 (salida 1)

    la $t5, TensionDiastol  # cargamos direcci�n de diast�lica
    lw $v1, 0($t5)          # guardamos el valor diast�lico en $v1 (salida 2)

    jr $ra                  # retornamos al main con los datos en $v0 y $v1
